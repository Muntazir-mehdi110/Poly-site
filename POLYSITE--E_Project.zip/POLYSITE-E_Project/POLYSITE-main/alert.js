function alert() {
    Swal.fire({
        title: "Item Bought",
        icon: "success",
        draggable: false
      });
}